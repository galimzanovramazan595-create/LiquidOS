package com.liquidos.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import android.content.pm.PackageManager
import android.os.Build
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private var drawerOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        buildHome()
    }

    private fun glass(bg: Int = 0xB91B1D20.toInt(), radius: Float = 28f): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius * resources.displayMetrics.density
            setColor(bg)
            setStroke((1 * resources.displayMetrics.density).toInt().coerceAtLeast(1), 0x66FFFFFF)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildHome() {
        root = FrameLayout(this)
        try {
            val wallpaper = WallpaperManager.getInstance(this).drawable
            val bg = ImageView(this).apply {
                setImageDrawable(wallpaper)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        } catch (_: Exception) {
            root.setBackgroundColor(0xFF202124.toInt())
        }

        val shade = View(this).apply {
            setBackgroundColor(0x66000000)
        }
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(54), dp(22), dp(28))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        showHome()
    }

    private fun showHome() {
        drawerOpen = false
        content.removeAllViews()

        val date = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date())
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val top = TextView(this).apply {
            text = "$time   •   ${date.replaceFirstChar { it.uppercase() }}"
            textSize = 15f
            setTextColor(Color.WHITE)
            setShadowLayer(8f, 0f, 2f, Color.BLACK)
            setPadding(dp(4), dp(4), dp(4), dp(12))
        }
        content.addView(top)

        val calendar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(0xD91D1F22.toInt(), 30f)
            setPadding(dp(20), dp(17), dp(20), dp(17))
        }
        val month = TextView(this).apply {
            text = SimpleDateFormat("LLLL", Locale("ru")).format(Date()).uppercase(Locale("ru"))
            textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(0xFFFF5555.toInt())
        }
        calendar.addView(month)
        val calText = TextView(this).apply {
            text = "ПН     ВТ     СР     ЧТ     ПТ     СБ     ВС\n\n     1      2      3      4      5      6      7\n\n     8      9     10    11    12    13    14"
            textSize = 13f; setTextColor(Color.WHITE); setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, dp(10), 0, 0)
        }
        calendar.addView(calText)
        val calLp = LinearLayout.LayoutParams(dp(260), dp(150))
        calLp.bottomMargin = dp(26)
        content.addView(calendar, calLp)

        val hint = TextView(this).apply {
            text = if (drawerOpen) "Приложения" else "Избранное"
            textSize = 13f; setTextColor(0xCCFFFFFF.toInt())
            setPadding(dp(3), 0, 0, dp(10))
        }
        content.addView(hint)
        val apps = getLaunchableApps().take(8)
        val grid = GridLayout(this).apply { columnCount = 4 }
        apps.forEach { app -> grid.addView(appTile(app), GridLayout.LayoutParams().apply {
            width = 0; height = dp(104); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(dp(2), dp(2), dp(2), dp(4))
        }) }
        content.addView(grid)

        val spacer = View(this)
        content.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val search = TextView(this).apply {
            text = "⌕   Поиск приложений"
            gravity = Gravity.CENTER
            textSize = 14f; setTextColor(Color.WHITE)
            background = glass(0x77232629, 40f)
            setPadding(dp(18), dp(11), dp(18), dp(11))
            setOnClickListener { showDrawer() }
        }
        val searchLp = LinearLayout.LayoutParams(-1, dp(46))
        searchLp.bottomMargin = dp(14)
        content.addView(search, searchLp)

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = glass(0x99232629.toInt(), 36f)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val dockApps = apps.take(4)
        dockApps.forEach { app ->
            val icon = ImageView(this).apply {
                setImageDrawable(app.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(13), dp(13), dp(13), dp(13))
                background = glass(0x772B2D30, 25f)
                setOnClickListener { launch(app) }
            }
            val lp = LinearLayout.LayoutParams(0, dp(62), 1f)
            lp.setMargins(dp(5), 0, dp(5), 0)
            dock.addView(icon, lp)
        }
        content.addView(dock, LinearLayout.LayoutParams(-1, dp(82)))
        root.setOnClickListener { }
        content.setOnLongClickListener { showDrawer(); true }
    }

    private fun showDrawer() {
        drawerOpen = true
        content.removeAllViews()
        val title = TextView(this).apply {
            text = "Все приложения"
            textSize = 27f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(16))
        }
        content.addView(title)
        val search = EditText(this).apply {
            hint = "Поиск"
            setSingleLine(true); textSize = 16f; setTextColor(Color.WHITE); setHintTextColor(0xAAFFFFFF.toInt())
            background = glass(0x99232629.toInt(), 28f)
            setPadding(dp(16), 0, dp(16), 0)
        }
        content.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply { columnCount = 4 }
        val all = getLaunchableApps()
        fun populate(q: String) {
            grid.removeAllViews()
            all.filter { it.loadLabel(packageManager).toString().contains(q, true) }.forEach { app ->
                grid.addView(appTile(app), GridLayout.LayoutParams().apply {
                    width = 0; height = dp(105); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(dp(2), dp(7), dp(2), dp(4))
                })
            }
        }
        populate("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        scroll.addView(grid)
        val lp = LinearLayout.LayoutParams(-1, 0, 1f); lp.topMargin = dp(12)
        content.addView(scroll, lp)
        val back = TextView(this).apply {
            text = "←  На главный экран"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE); textSize = 15f
            background = glass(0x77232629, 30f)
            setPadding(dp(12), dp(13), dp(12), dp(13))
            setOnClickListener { showHome() }
        }
        content.addView(back, LinearLayout.LayoutParams(-1, dp(48)))
    }

    private fun appTile(app: android.content.pm.ApplicationInfo): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            isClickable = true
            setOnClickListener { launch(app) }
        }
        val icon = ImageView(this).apply {
            setImageDrawable(app.loadIcon(packageManager))
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = glass(0xB52A2C30.toInt(), 25f)
            setPadding(dp(13), dp(13), dp(13), dp(13))
        }
        box.addView(icon, LinearLayout.LayoutParams(dp(58), dp(58)))
        val label = TextView(this).apply {
            text = app.loadLabel(packageManager).toString()
            textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            maxLines = 1; setShadowLayer(5f, 0f, 1f, Color.BLACK)
            setPadding(0, dp(5), 0, 0)
        }
        box.addView(label, LinearLayout.LayoutParams(-1, dp(25)))
        return box
    }

    private fun getLaunchableApps(): List<android.content.pm.ApplicationInfo> {
        val pm = packageManager
        val apps = if (Build.VERSION.SDK_INT >= 33) pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
                   else @Suppress("DEPRECATION") pm.getInstalledApplications(0)
        return apps.filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) }
    }

    private fun launch(app: android.content.pm.ApplicationInfo) {
        packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) showHome() else super.onBackPressed()
    }
}
